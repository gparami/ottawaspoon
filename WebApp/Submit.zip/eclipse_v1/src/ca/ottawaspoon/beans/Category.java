package ca.ottawaspoon.beans;

public class Category {

	public Category(String name) {
		super();
		this.name = name;
	}

	private String name;
	
	public Category() {
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
