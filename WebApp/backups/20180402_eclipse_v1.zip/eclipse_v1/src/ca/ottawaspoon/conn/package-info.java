/**
 * This package contains the connection scripts to the postgreSQL database.
 */
/**
 * @author parami
 *
 */
package ca.ottawaspoon.conn;