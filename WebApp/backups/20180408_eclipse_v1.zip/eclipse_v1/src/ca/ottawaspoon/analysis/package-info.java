/**
 * 
 */
/**
 * Conducting sentiment analysis.
 * @author artem
 *
 */
package ca.ottawaspoon.analysis;