/**
 * 
 */
/**
 * @author parami
 * This package holds all the servlets.
 */
package ca.ottawaspoon.servlet;