/**
 * This package handles session management, cookie handling, queries and data manipulation.
 */
/**
 * @author parami
 *
 */
package ca.ottawaspoon.utils;