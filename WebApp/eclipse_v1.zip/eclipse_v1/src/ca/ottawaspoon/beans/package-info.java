/**
 * Beans Beans Beans
 */
/**
 * @author parami
 *
 */
package ca.ottawaspoon.beans;